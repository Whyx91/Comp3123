
module.exports.add = function(a, b){
    return a + b
}

exports.sub = (a,b) => {
    return a - b
}

let name = "Pritesh"

exports.name = name